to build tailwind

```
npx tailwindcss -i .\public\input.css -o .\public\style.css --watch
```